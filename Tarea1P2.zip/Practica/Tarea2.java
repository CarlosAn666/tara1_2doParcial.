
public class Tarea2
{
    public void sucesion(int cantidad)
    {
        int arreglo[] = new int[cantidad];
        if(cantidad > 0){
            System.out.print(1+" ");
            if(cantidad > 1){
                System.out.print(1+" ");
            }
            if(cantidad > 2){
                System.out.print(1+" ");
            }
            arreglo[0] =1;
            arreglo[1] =1;
            arreglo[2] =1;
            int contador = 3;
            while(contador < cantidad){
                arreglo[contador] = arreglo[contador-3]+arreglo[contador-2];
                System.out.print(arreglo[contador]+" ");
                contador++;
            }
        }else{
            System.out.println("Ingrese valores positivos");
        }
    }
}
