
public class Tarea1
{
    public void sucesion(int cantidad)
    {
        if(cantidad > 0){
            int numero = 1;
            System.out.print(1+" ");
            int sum = 1;
            int contador = 1;
            boolean estaSubiendo = false;
            while(contador < cantidad && contador < cantidad){
                numero = numero + sum ;
                System.out.print(numero+" ");
                if(sum == 1){
                    sum = 2;
                    estaSubiendo = true;
                }else if(sum == 3){
                    sum = 2;
                    estaSubiendo = false;
                }else{
                    if(estaSubiendo == true){
                        sum = 3;
                    }else{
                        sum = 1;
                    }
                }
                contador++;
            }
            int indice = 0;
        }else{
            System.out.println("La sucesion solo funciona con numeros positivos");
        }
    }
}
